const {body} = require('express-validator');


exports.Validation =[
    body('personname').notEmpty().withMessage('Person Name is required').isLength({min:2}).withMessage('Person Name Should greater than 2').trim(),

    body('gender').notEmpty().withMessage('Select Gender'),

    body('address').notEmpty().withMessage('Address is required').trim(),

    body('contactdetails.*.email').notEmpty().withMessage('Email ID is required').isEmail().withMessage('Invalid Email').trim(),
    
    body('contactdetails.*.number').notEmpty().withMessage('Mobile Number is required').isMobilePhone().withMessage('Invalid Contact Number').trim(),
    
    body('contactdetails.*.addtype').notEmpty().withMessage('Please Select Any List'),
]