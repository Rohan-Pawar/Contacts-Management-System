const mongoose = require('mongoose');
var NewUser = mongoose.model('User', {

    personname: {
        type: String,
        required: true,
        // lowercase: true,
        // uppercase: true,
        trim: true,
        // minLength: 2,
        // maxLength:50

    },
    gender: {
        required: true,
        type: String
        // uppercase:true,
        // lowercase:true
    },
    address: {
        type: String,
        required: true,
        trim: true
        // minLength: 2,
        //    maxLength:250
    },
    contactdetails: [{


        number: {
            type: Number,
            required: true,
            trim: true
            // min: 10,
            // maxLength:13
        },
        email: {
            type: String,
            lowercase:true,
            required: [true,'Email Is Required'],
            maxlength:[128,'Email cannot be greater than 128 characters'],
            index:true,
            unique: true
        },
        addtype: {
            type: String,
            required: true,
            trim: true,
        }


    }]
});
module.exports = {
    NewUser
};