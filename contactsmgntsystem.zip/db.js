const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/contactbook', ({ useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex: true }), (err) => {
    if(!err)
    {
        console.log('MongoDB Is Connectect On contactbook databse');
    }

    else
    {
        console.log('Error In Connecting Data Base', + JSON.stringify(err, undefined, 2));
    }

});
module.exports = mongoose;