//importing express for creating backend server/ requires the express module
const express = require('express');

//importing cors for communicating frontend and backend..it required for connecting different url/localhost servers
const cors = require('cors');

// const {validationResult}= require('express-validator');
// const {Validation}= require('../validation/check');

//importing body-parser parsing the incoming request bodies in a middleware before you handle it
const bodyparser = require('body-parser');

//asining port number of running server on that port
const port = 3000;

//importing local mongoose module 
const { mongoose } = require('./db');

//defining routing path
var userController = require('./controllers/userController');

//calling express server in app variable
var app = express();

app.use(bodyparser.urlencoded({extended:false}));

app.use(express.json());
// app.use(bodyparser.json());
app.use(cors({origin:'http://localhost:4200'}));

//localhost:3000/users
app.use('/users', userController);

//server listening here on port number 3000
app.listen(port , () => {
    console.log('Server Is Running On Port :-', + port);
});