const express = require('express');
var router = express.Router();
var ObjectID = require('mongodb').ObjectId;
var {
    NewUser
} = require('../models/user');


router.get('/', (req, res) => {
    NewUser.find((err, docs) => {
        if (!err) {
            // const mdata = JSON.stringify(docs);
            // console.log(mdata);
            res.send(docs);
        } else {

            console.log('Error In Retriving Users Data :-' + JSON.stringify(err, undefined, 2));
            res.send('Error In Retriving Users Data :-' + JSON.stringify(err, undefined, 2));
        }
    });
});


router.get('/:id', (req, res) => {
    if (!ObjectID.isValid(req.params.id)) {
        res.status(400).send(`no record ${req.params.id}`);
    } else {
        NewUser.findById(req.params.id, (err, docs) => {
            if (!err) {
            // const mdata = JSON.stringify(docs);
            // console.log(mdata);
                res.send(docs);
            } else {
                console.log('Error' + JSON.stringify(err, undefined, 2));
                res.send('Error In Retriving Data by User ID :-' + JSON.stringify(err, undefined, 2));
            }
        });
    }
});




router.post('/', async (req, res) => {

    const length = req.body.contactdetails.length;
    console.log(length);

    var duplicate=false;

    for(var i = 0; i<length; i++)

    {
        var emailfound= await NewUser.findOne({ $or:[{"contactdetails.email": req.body.contactdetails[i].email}, {"contactdetails.number": req.body.contactdetails[i].number}]});

        //  console.log("You Inserted email Is Aleardy In DataBase :-",emailfound);
         if(emailfound)
         {
             duplicate=true;
             break;
         }


    }

    if(duplicate)
    {
         console.log("Email is already OR mobile number is present",emailfound);
    }

    
else
{
    console.log("email and mobile number can be added into database");
        var data = new NewUser({
        personname: req.body.personname,
        gender: req.body.gender,
        address: req.body.address,
        contactdetails: req.body.contactdetails







    });


        data.save((err, docs) => {
        if (!err) {
            // const mdata = JSON.stringify(docs);
            // console.log(mdata);
            res.send('New Data has been Saved successfully' + docs);
        } else {
            console.log('Error In Saving New Data' + JSON.stringify(err, undefined, 2));
            res.send('Error In Saving Data' + JSON.stringify(err, undefined, 2));
        }
    });





}

});























// router.post('/', async (req, res) => {

//     const length = req.body.contactdetails.length;
//     console.log(length);

//     var duplicate=false;

//     for(var i = 0; i<length; i++)

//     {
//         var emailfound= await NewUser.findOne({"contactdetails.email": req.body.contactdetails[i].email});

//          console.log("email found is",emailfound);
//          if(emailfound)
//          {
//              duplicate=true;
//              break;
//          }


//     }

//     if(duplicate)
//     {
//          console.log("email is found in db");
//          res.send("Email is present in database");
//     }

    
// else
// {
//     console.log("email can be added into database");
//         var data = new NewUser({
//         personname: req.body.personname,
//         gender: req.body.gender,
//         address: req.body.address,
//         contactdetails: req.body.contactdetails







//     });


//         data.save((err, docs) => {
//         if (!err) {
//             // const mdata = JSON.stringify(docs);
//             // console.log(mdata);
//             res.send('New Data has been Saved successfully' + docs);
//         } else {
//             console.log('Error In Saving New Data' + JSON.stringify(err, undefined, 2));
//             res.send('Error In Saving Data' + JSON.stringify(err, undefined, 2));
//         }
//     });





// }

// });




router.put('/:id', (req, res) => {
    if (!ObjectID.isValid(req.params.id)) {
        res.status(400).send(`No Record with given ID :- ${req.params.id}`);
    } else

    {
        var data = {


            personname: req.body.personname,
            gender: req.body.gender,
            address: req.body.address,
            contactdetails: req.body.contactdetails


        }

        NewUser.findByIdAndUpdate(req.params.id, {
            $set: data
        }, {
            new: true
        }, (err, docs) => {
            if (!err) {
                console.log(docs);
                res.send(docs);
            } else {
                console.log('Error In Updating Record' + JSON.stringify(err, undefined, 2));
            }
        });
    }

});
router.delete('/:id', (req, res) => {
    if (!ObjectID.isValid(req.params.id)) {
        res.status(400).send(`No Recored With Given ID :- ${req.params.id}`);
    } else {
        NewUser.findByIdAndRemove(req.params.id, (err, docs) => {
            if (!err) {
                res.send('Deleted User Information With Give ID' + docs);
            } else {
                console.log('Error in User deletion' + JSON.stringify(err, undefined, 2));
            }
        });
    }
});
module.exports = router;