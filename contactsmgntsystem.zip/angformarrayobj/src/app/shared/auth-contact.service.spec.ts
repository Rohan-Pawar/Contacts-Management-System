/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { AuthContactService } from './auth-contact.service';

describe('Service: AuthContact', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AuthContactService]
    });
  });

  it('should ...', inject([AuthContactService], (service: AuthContactService) => {
    expect(service).toBeTruthy();
  }));
});
