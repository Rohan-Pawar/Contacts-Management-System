export interface Contactuser {
    personname:string;
    gender:string;
    address:string;
    contactdetails:[
        {   
        number:Number;
        email:string;
        addtype:string;
        }
      ]
}