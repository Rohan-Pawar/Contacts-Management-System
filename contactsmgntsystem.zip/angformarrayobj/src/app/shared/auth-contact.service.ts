import { Injectable } from '@angular/core';
import { Contactuser } from '../shared/contactuser';
import { Observable, throwError } from 'rxjs';
import { catchError, map, retry } from 'rxjs/operators';
import { HttpClient, HttpErrorResponse, HttpHeaders } from "@angular/common/http";

@Injectable({
    providedIn: 'root'
  })
export class AuthContactService {

    users: Contactuser[] | any;
    contactuser: Contactuser | any;


  //fetch backend endpoint check
  // http://localhost:3000/users
  readonly baseURL="http://localhost:3000/users";


  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json'
    })
  };
constructor(public http:HttpClient) { }

/** GET heroes from the server */
getAllContact(contacts: any): Observable<Contactuser> {
  console.log('All User Details');
    return this.http.get<Contactuser>(this.baseURL);
  }


// get current data
getCurrentData(_id: number): Observable<Contactuser[]> 
{
  console.log('Get Users Data By Its ID');
  return this.http.get<Contactuser[]>(this.baseURL + `/${_id}`);
}
//updating existing datas
putcontacts(_id: any,contacts:any): Observable<any> {
  window.alert('Are You Update Existing Data...?In Service Section');
  // + `/${newdatas._id}` followed by this.baseURL
  return this.http.put<Contactuser[]>(this.baseURL + `/${_id}`, contacts, this.httpOptions)

}


//deleting existing data by selecting its it
deleteUser(_id: any):Observable<any>
{
  return this.http.delete<Contactuser[]>(this.baseURL + `/${_id}`);
}




  /** POST: add a new hero to the database */
  addcontact(contacts:any){
    // window.alert('Your New Contact Details Are Added Sucessfully');
   return this.http.post<any>(this.baseURL, contacts, this.httpOptions);
   }
}