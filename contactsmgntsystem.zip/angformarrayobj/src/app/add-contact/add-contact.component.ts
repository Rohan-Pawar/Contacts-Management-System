import { Component, OnInit } from '@angular/core';
import { FormArray,FormBuilder,FormGroup,FormControl,Validators, PatternValidator} from "@angular/forms";
import { AuthContactService } from '../shared/auth-contact.service';
import { HttpClient } from '@angular/common/http';
import { Contactuser } from '../shared/contactuser';
declare var M: any;




@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html',
  styleUrls: ['./add-contact.component.css']
})
export class AddContactComponent implements OnInit {
 
  contactuser: Contactuser;
  Contactusers:Contactuser[]| any;
 

  contactForm=this.fb.group({
    id:this.fb.control(''),
    personname:this.fb.control('',[Validators.required]),
    gender:this.fb.control('',[Validators.required]),
    address:this.fb.control('',[Validators.required]),
    contactdetails:this.fb.array([ 
      this.fb.group({
        number:this.fb.control('',[Validators.required]),
        email:this.fb.control('',[Validators.required]),
        addtype:this.fb.control('',[Validators.required])
       })
     ])
  })
  newdatas: string;
  controldata: string;
  userDetails: any;
  snapshot: any;



  constructor(public fb: FormBuilder, public authContactService: AuthContactService, public https: HttpClient ) { }
  Emp:string[] | any;    
 
 


  ngOnInit() {    
  
    this.https.get<any>('http://localhost:3000/users').subscribe(newdata=>    
      {    
        // retriving all datas from mongoDB
       this.Emp = newdata as string [];
   
      //  window.alert("this.Emp"+JSON.stringify(this.Emp));
   
      
      // this.authContactService.getAllContact(this.Contactusers)
      this.authContactService.getAllContact(this.Emp)
      .subscribe( contacts => {
        this.Contactusers = contacts;
        // window.alert("Contactusers"+JSON.stringify(this.Contactusers));
      });
   
      });      
   
      this.contactForm=this.fb.group({
        id:this.fb.control(''),
        personname:this.fb.control('',[Validators.required]),
        gender:this.fb.control('',[Validators.required]),
        address:this.fb.control('',[Validators.required]),
        contactdetails:this.fb.array([
           this.addingFormDetailss()
            
         ])
      })


  }   

  get f(){
    // window.alert(this.contactForm.controls);
    return this.contactForm.controls
  }

//get method FormArray

get contactdetails(): FormArray {
  return this.contactForm.get('contactdetails') as FormArray;
  // window.alert(this.contactdetails);
}
//adding more contact details
addFormDetails()
{
  this.contactdetails.push(
    this.fb.group({
      number:this.fb.control(''),
      email:this.fb.control(''),
      addtype:this.fb.control('')
    })
  );
}
addingFormDetailss():FormGroup{
  return this.fb.group({
    number:[''],
    email:[''],
    addtype:['']
  });
}


//removeving extra contact details

removeDetails(i:any)

{
  this.contactdetails.removeAt(i);
}



onSubmit()
{

  // var gemailid=   this.contactdetails.get('email');

  var contacts = JSON.stringify(this.contactForm.value);
// window.alert(gemailid);
  // window.alert( "Your now on Submit Button" +contacts);

 this.authContactService.addcontact(contacts)
 .subscribe(
  (error)=>
  { 
 window.alert("Error in storing New Contact Details In MongoDB");
 console.log(error);
  },
  (contacts)=>
  { 
    window.alert("New Contact Details are Added Sucessfully");
    console.log(contacts);
  }
  );
}


//reset form

resetForm() {
  this.contactForm.reset();
}


  onEdit(data:any){
  

    // var newnewdata= JSON.stringify(data.contactdetails);

    this.contactForm.patchValue({
      id:data._id,
      personname:data.personname,
      gender:data.gender,
      address:data.address

  });
  
 
this.contactForm.setControl('contactdetails', this.setnewcontactdetails(data.contactdetails));
}

setnewcontactdetails(dataset: any[]):FormArray{
  const formArray = new FormArray([]);
  dataset.forEach(data=>{
    formArray.push(this.fb.group({
      number:data.number,
      email:data.email,
      addtype:data.addtype
      
    }));
  });

  return formArray;
  
}

onUpdate(id: any,contactForm: any){
  window.alert("Do You Want To Update This Data.....are you sure???");
  var contacts= JSON.stringify(this.contactForm.value);
  return this.authContactService.putcontacts(id,contacts)
  .subscribe(
             (contacts)=>{ 
            window.alert("Contact Details Updated Sucessfully");
            console.log(contacts);
          },
             (error)=>{ console.log(error);}
             );
}


onDelete(_id: string, contactForm: FormGroup) 
{
  if (confirm('Are You Sure To Delete This Record ?') == true)
  {
    this.authContactService.deleteUser(_id).subscribe((res) => {

      M.toast({ html: 'Deleted Successfully', classes: 'rounded'});
      // this.refreshUserList();
      this.resetForm();
    });
  }
}
}